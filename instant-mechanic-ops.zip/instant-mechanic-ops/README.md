# Instant Mechanic — Live Ops Dashboard

2-day Internshala assignment (full-stack intern).

A small operations dashboard for vehicle service bookings. Scope is only what the brief asked for so it could actually be finished in two days.

## What it does

- Overview KPIs (bookings, revenue, mechanics, new customers)
- Analytics charts
- Bookings table: search, status filter, sort, pagination
- Booking detail + status timeline
- Mechanics and customers lists
- Live status updates without a full page reload (SSE locally; demo on Vercel is a snapshot)

## Stack

- Frontend: Next.js + TypeScript + Tailwind + shadcn/ui
- Backend: Express + Prisma + SQLite
- Live: WebSocket + SSE + a tiny booking-status simulator

```
Browser → Next.js (43123)
              ↓ /api
         Express (43124) → SQLite
```

On Vercel I also run the same read APIs inside Next.js so the demo works without a separate AWS box.

## Run locally

Node 22.

```bash
# terminal 1 — API
cd backend
cp .env.example .env
npm install
npx prisma db push
npx tsx prisma/seed.ts
npm run dev

# terminal 2 — UI
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

- App: http://127.0.0.1:43123
- API: http://127.0.0.1:43124/api/health
- Swagger: http://127.0.0.1:43124/api/docs

Seed: 560 bookings, 60 customers, 24 mechanics.

## Env

Backend: `PORT`, `DATABASE_URL`, `CORS_ORIGIN`, `SIMULATOR_ENABLED`  
Frontend: leave `NEXT_PUBLIC_API_URL` empty locally (browser talks to `/api`).

## APIs

- `GET /api/dashboard`
- `GET /api/bookings` (search, status, sort, page)
- `GET /api/bookings/:id`
- `PATCH /api/bookings/:id/status`
- `GET /api/mechanics`
- `GET /api/customers`
- `GET /api/events` (SSE)
- `WS /ws`

## Deploy

- Frontend: Vercel, project folder `frontend`
- Backend: would go on a small AWS EC2/Lightsail instance (skipped in two days; Vercel Next `/api` is the public demo)
- GitHub: push this repo

## AI usage

Used Cursor for scaffolding, seed data, and debugging. Schema, filters, and the live status flow are things I can walk through.

Skipped because of time: login, Postgres on AWS, maps.
